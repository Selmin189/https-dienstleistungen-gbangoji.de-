import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

const SITE_TITLE = "Dienstleistungen Galjip Bangoji – Hausmeisterservice & Gebäudereinigung Braunschweig";
const SITE_DESC = "Zuverlässige Dienstleistungen rund um Haus, Gebäude und Außenanlagen in Braunschweig und Niedersachsen. Gartenpflege, Reinigung, Hausmeisterservice, Entrümpelung und Renovierung – alles aus einer Hand.";

const orgSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "https://www.dienstleistungen-gbangoji.de/#business",
  name: "Dienstleistungen Galjip Bangoji",
  image: "https://www.dienstleistungen-gbangoji.de/__l5e/assets-v1/b072d248-f868-431b-af9e-156fdde1a832/logo.png",
  logo: "https://www.dienstleistungen-gbangoji.de/__l5e/assets-v1/b072d248-f868-431b-af9e-156fdde1a832/logo.png",
  telephone: "+49 176 70672677",
  email: "info@dienstleistungen-gbangoji.de",
  url: "https://www.dienstleistungen-gbangoji.de",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Alte Salzdahlumer Straße 208",
    postalCode: "38124",
    addressLocality: "Braunschweig",
    addressRegion: "Niedersachsen",
    addressCountry: "DE",
  },
  areaServed: [
    { "@type": "City", name: "Braunschweig" },
    { "@type": "State", name: "Niedersachsen" },
  ],
  priceRange: "€€",
  founder: { "@type": "Person", name: "Galjip Bangoji" },
};

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Seite nicht gefunden</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Die gesuchte Seite existiert nicht oder wurde verschoben.
        </p>
        <div className="mt-6">
          <Link to="/" className="btn-navy inline-flex items-center justify-center rounded-md px-5 py-2.5 text-sm">
            Zur Startseite
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Diese Seite konnte nicht geladen werden
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Es ist ein Fehler aufgetreten. Bitte versuchen Sie es erneut.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => { router.invalidate(); reset(); }}
            className="btn-navy inline-flex items-center justify-center rounded-md px-5 py-2.5 text-sm"
          >
            Erneut versuchen
          </button>
          <a href="/" className="inline-flex items-center justify-center rounded-md border border-input bg-background px-5 py-2.5 text-sm font-medium hover:bg-accent">
            Zur Startseite
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: SITE_TITLE },
      { name: "description", content: SITE_DESC },
      { name: "author", content: "Dienstleistungen Galjip Bangoji" },
      { name: "keywords", content: "Hausmeisterservice Braunschweig, Gebäudereinigung Braunschweig, Gartenpflege Braunschweig, Entrümpelung Braunschweig, Renovierung Braunschweig, Dienstleistungen Niedersachsen, Objektbetreuung, Winterdienst Braunschweig" },
      { property: "og:site_name", content: "Dienstleistungen Galjip Bangoji" },
      { property: "og:title", content: SITE_TITLE },
      { property: "og:description", content: SITE_DESC },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "de_DE" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: SITE_TITLE },
      { name: "twitter:description", content: SITE_DESC },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "apple-touch-icon", href: "/favicon.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700;800&display=swap" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(orgSchema),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
