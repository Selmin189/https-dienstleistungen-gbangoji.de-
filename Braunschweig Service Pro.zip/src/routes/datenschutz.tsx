import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/datenschutz")({
  head: () => ({
    meta: [
      { title: "Datenschutz – Dienstleistungen Galjip Bangoji" },
      { name: "description", content: "Datenschutzerklärung von Dienstleistungen Galjip Bangoji, Braunschweig." },
      { name: "robots", content: "index,follow" },
      { property: "og:title", content: "Datenschutz – Dienstleistungen Galjip Bangoji" },
      { property: "og:description", content: "Informationen zum Datenschutz nach DSGVO." },
      { property: "og:url", content: "/datenschutz" },
    ],
    links: [{ rel: "canonical", href: "/datenschutz" }],
  }),
  component: DatenschutzPage,
});

function DatenschutzPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="pt-32 pb-20">
        <div className="container-page max-w-3xl">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Zurück zur Startseite</Link>
          <h1 className="mt-4 text-4xl font-bold text-foreground gold-underline">Datenschutzerklärung</h1>

          <div className="mt-10 space-y-8 text-foreground">
            <section className="space-y-2">
              <h2 className="text-lg font-semibold">1. Verantwortlicher</h2>
              <p>Dienstleistungen Galjip Bangoji<br />Galjip Bangoji<br />Alte Salzdahlumer Straße 208, 38124 Braunschweig</p>
              <p>Telefon: 0176 70672677 · E-Mail: info@dienstleistungen-gbangoji.de</p>
            </section>

            <section className="space-y-2">
              <h2 className="text-lg font-semibold">2. Allgemeines zur Datenverarbeitung</h2>
              <p className="text-muted-foreground text-sm">
                Wir verarbeiten personenbezogene Daten unserer Nutzer grundsätzlich nur, soweit dies zur
                Bereitstellung einer funktionsfähigen Website sowie unserer Inhalte und Leistungen
                erforderlich ist. Rechtsgrundlage ist Art. 6 Abs. 1 lit. a, b und f DSGVO.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-lg font-semibold">3. Kontaktaufnahme</h2>
              <p className="text-muted-foreground text-sm">
                Bei der Kontaktaufnahme per Kontaktformular, E-Mail oder Telefon werden die von Ihnen
                mitgeteilten Daten (Name, Telefon, E-Mail, Nachricht) zur Bearbeitung Ihrer Anfrage
                gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-lg font-semibold">4. Server-Logfiles</h2>
              <p className="text-muted-foreground text-sm">
                Der Provider erhebt und speichert automatisch Informationen in Server-Logfiles, die
                Ihr Browser übermittelt (IP-Adresse, Browsertyp, Uhrzeit der Anfrage). Diese Daten
                sind nicht bestimmten Personen zuordenbar.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-lg font-semibold">5. Ihre Rechte</h2>
              <p className="text-muted-foreground text-sm">
                Sie haben jederzeit das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der
                Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Wenden Sie sich hierfür an die
                oben genannten Kontaktdaten. Zudem steht Ihnen ein Beschwerderecht bei einer
                Aufsichtsbehörde zu.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-lg font-semibold">6. SSL-Verschlüsselung</h2>
              <p className="text-muted-foreground text-sm">
                Diese Seite nutzt aus Gründen der Sicherheit eine SSL-Verschlüsselung. Eine
                verschlüsselte Verbindung erkennen Sie in der Adresszeile Ihres Browsers.
              </p>
            </section>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
