import { useState, type FormEvent } from "react";
import { toast } from "sonner";

const services = [
  "Gartenpflege & Außenpflege",
  "Reinigungsarbeiten",
  "Hausmeisterservice",
  "Entrümpelung & Rückbau",
  "Montage & Renovierung",
  "Sonstiges",
];

export function ContactForm() {
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = {
      name: String(data.get("name") ?? "").trim(),
      email: String(data.get("email") ?? "").trim(),
      phone: String(data.get("phone") ?? "").trim(),
      service: String(data.get("service") ?? "").trim(),
      message: String(data.get("message") ?? "").trim(),
    };

    try {
      const res = await fetch("/api/public/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body?.error || "Fehler beim Senden");
      }

      toast.success("Vielen Dank! Ihre Anfrage wurde gesendet. Wir melden uns schnellstmöglich.");
      form.reset();
    } catch (err) {
      console.error(err);
      toast.error(
        "Ihre Anfrage konnte nicht gesendet werden. Bitte rufen Sie uns direkt an: 0176 70672677",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-4">
      <div className="grid md:grid-cols-2 gap-4">
        <Field label="Name" name="name" required />
        <Field label="Telefon" name="phone" type="tel" required />
      </div>
      <Field label="E-Mail" name="email" type="email" required />
      <div>
        <label className="text-sm font-medium text-foreground" htmlFor="service">Gewünschte Dienstleistung</label>
        <select
          id="service"
          name="service"
          required
          className="mt-1.5 w-full h-11 rounded-md border border-input bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          defaultValue=""
        >
          <option value="" disabled>Bitte wählen…</option>
          {services.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      <div>
        <label className="text-sm font-medium text-foreground" htmlFor="message">Nachricht</label>
        <textarea
          id="message"
          name="message"
          required
          rows={5}
          maxLength={2000}
          placeholder="Beschreiben Sie kurz Ihr Anliegen…"
          className="mt-1.5 w-full rounded-md border border-input bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>
      <button
        type="submit"
        disabled={loading}
        className="btn-gold rounded-md px-6 py-3 text-sm mt-2 disabled:opacity-70"
      >
        {loading ? "Wird gesendet…" : "Kostenloses Angebot anfragen"}
      </button>
      <p className="text-xs text-muted-foreground">
        Mit dem Absenden erklären Sie sich mit unserer{" "}
        <a href="/datenschutz" className="underline hover:text-foreground">Datenschutzerklärung</a> einverstanden.
      </p>
    </form>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-sm font-medium text-foreground" htmlFor={name}>{label}</label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        maxLength={255}
        className="mt-1.5 w-full h-11 rounded-md border border-input bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}
