import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/impressum")({
  head: () => ({
    meta: [
      { title: "Impressum – Dienstleistungen Galjip Bangoji" },
      { name: "description", content: "Impressum und rechtliche Angaben von Dienstleistungen Galjip Bangoji, Braunschweig." },
      { name: "robots", content: "index,follow" },
      { property: "og:title", content: "Impressum – Dienstleistungen Galjip Bangoji" },
      { property: "og:description", content: "Rechtliche Angaben nach § 5 TMG." },
      { property: "og:url", content: "/impressum" },
    ],
    links: [{ rel: "canonical", href: "/impressum" }],
  }),
  component: ImpressumPage,
});

function ImpressumPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="pt-32 pb-20">
        <div className="container-page max-w-3xl">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Zurück zur Startseite</Link>
          <h1 className="mt-4 text-4xl font-bold text-foreground gold-underline">Impressum</h1>

          <section className="mt-10 space-y-2 text-foreground">
            <h2 className="text-lg font-semibold">Angaben gemäß § 5 TMG</h2>
            <p>Dienstleistungen Galjip Bangoji</p>
            <p>Inhaber: Galjip Bangoji</p>
            <p>Alte Salzdahlumer Straße 208<br />38124 Braunschweig<br />Deutschland</p>
          </section>

          <section className="mt-8 space-y-2 text-foreground">
            <h2 className="text-lg font-semibold">Kontakt</h2>
            <p>Telefon: <a className="underline hover:text-foreground" href="tel:+4917670672677">0176 70672677</a></p>
            <p>E-Mail: <a className="underline hover:text-foreground" href="mailto:info@dienstleistungen-gbangoji.de">info@dienstleistungen-gbangoji.de</a></p>
            <p>Web: www.dienstleistungen-gbangoji.de</p>
          </section>

          <section className="mt-8 space-y-2 text-foreground">
            <h2 className="text-lg font-semibold">Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
            <p>Galjip Bangoji, Anschrift wie oben.</p>
          </section>

          <section className="mt-8 space-y-3 text-sm text-muted-foreground">
            <h2 className="text-lg font-semibold text-foreground">Haftungsausschluss</h2>
            <p>
              Die Inhalte dieser Website wurden mit größter Sorgfalt erstellt. Für die Richtigkeit,
              Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen.
              Für Inhalte externer Links sind ausschließlich deren Betreiber verantwortlich.
            </p>
            <p>
              EU-Streitschlichtung: Die Europäische Kommission stellt eine Plattform zur
              Online-Streitbeilegung (OS) bereit:{" "}
              <a href="https://ec.europa.eu/consumers/odr/" target="_blank" rel="noreferrer" className="underline">
                https://ec.europa.eu/consumers/odr/
              </a>. Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer
              Verbraucherschlichtungsstelle teilzunehmen.
            </p>
          </section>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
