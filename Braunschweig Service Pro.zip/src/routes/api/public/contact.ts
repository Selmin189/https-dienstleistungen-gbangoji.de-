import { createFileRoute } from '@tanstack/react-router'
import { z } from 'zod'
import { sendTemplateEmail } from '@/lib/email-templates/send-email'

const contactSchema = z.object({
  name: z.string().trim().min(1, 'Name erforderlich').max(100),
  email: z.string().trim().email('Ungültige E-Mail').max(255),
  phone: z.string().trim().min(1, 'Telefon erforderlich').max(50),
  service: z.string().trim().min(1, 'Dienstleistung erforderlich').max(100),
  message: z.string().trim().min(1, 'Nachricht erforderlich').max(2000),
})

export const Route = createFileRoute('/api/public/contact')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let payload: unknown
        try {
          payload = await request.json()
        } catch {
          return Response.json({ error: 'Ungültige Anfrage' }, { status: 400 })
        }

        const parsed = contactSchema.safeParse(payload)
        if (!parsed.success) {
          return Response.json(
            { error: 'Ungültige Eingabe', issues: parsed.error.flatten() },
            { status: 400 },
          )
        }

        const data = parsed.data
        const idempotencyKey = `contact-${data.email}-${Date.now()}`

        try {
          const result = await sendTemplateEmail('contact-inquiry', data.email, {
            templateData: data,
            replyTo: data.email,
            idempotencyKey,
          })

          if (!result.sent) {
            console.warn('Contact email not sent:', result.reason)
          }

          return Response.json({ ok: true })
        } catch (error) {
          console.error('Contact form send failed:', error)
          return Response.json(
            { error: 'E-Mail konnte nicht versendet werden. Bitte versuchen Sie es später erneut.' },
            { status: 500 },
          )
        }
      },
    },
  },
})
