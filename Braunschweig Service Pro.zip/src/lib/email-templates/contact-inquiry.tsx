import React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

interface Props {
  name?: string
  email?: string
  phone?: string
  service?: string
  message?: string
}

const ContactInquiryEmail = ({ name, email, phone, service, message }: Props) => (
  <Html lang="de" dir="ltr">
    <Head />
    <Preview>Neue Kundenanfrage von {name || 'Ihrer Website'}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Neue Anfrage über Ihre Website</Heading>
        <Text style={intro}>
          Sie haben eine neue Anfrage über das Kontaktformular auf
          dienstleistungen-gbangoji.de erhalten.
        </Text>

        <Section style={card}>
          <Row label="Name" value={name} />
          <Row label="E-Mail" value={email} />
          <Row label="Telefon" value={phone} />
          <Row label="Dienstleistung" value={service} />
        </Section>

        <Heading as="h2" style={h2}>Nachricht</Heading>
        <Text style={messageBox}>{message || '—'}</Text>

        <Hr style={hr} />
        <Text style={footer}>
          Diese Nachricht wurde automatisch von Ihrer Website versendet.
        </Text>
      </Container>
    </Body>
  </Html>
)

const Row = ({ label, value }: { label: string; value?: string }) => (
  <Text style={rowText}>
    <strong style={rowLabel}>{label}:</strong> {value || '—'}
  </Text>
)

export const template = {
  component: ContactInquiryEmail,
  subject: (data: Record<string, any>) =>
    `Neue Anfrage: ${data.service || 'Kontaktformular'}${data.name ? ` – ${data.name}` : ''}`,
  displayName: 'Kontaktanfrage (intern)',
  to: 'info@dienstleistungen-gbangoji.de',
  previewData: {
    name: 'Max Mustermann',
    email: 'max@example.com',
    phone: '0171 1234567',
    service: 'Gartenpflege & Außenpflege',
    message: 'Guten Tag, ich hätte gerne ein Angebot für einen Heckenschnitt. Vielen Dank!',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { padding: '32px 28px', maxWidth: '600px', margin: '0 auto' }
const h1 = { color: '#0b1f3a', fontSize: '22px', margin: '0 0 12px', fontWeight: 700 }
const h2 = { color: '#0b1f3a', fontSize: '16px', margin: '24px 0 8px', fontWeight: 600 }
const intro = { color: '#4a5568', fontSize: '14px', margin: '0 0 20px', lineHeight: '22px' }
const card = {
  backgroundColor: '#f7f9fc',
  border: '1px solid #e2e8f0',
  borderRadius: '10px',
  padding: '18px 20px',
}
const rowText = { color: '#1a202c', fontSize: '14px', margin: '6px 0', lineHeight: '20px' }
const rowLabel = { color: '#0b1f3a', display: 'inline-block', minWidth: '110px' }
const messageBox = {
  color: '#1a202c',
  fontSize: '14px',
  lineHeight: '22px',
  whiteSpace: 'pre-wrap' as const,
  backgroundColor: '#f7f9fc',
  border: '1px solid #e2e8f0',
  borderRadius: '10px',
  padding: '16px 18px',
  margin: '0',
}
const hr = { borderColor: '#e2e8f0', margin: '28px 0 16px' }
const footer = { color: '#94a3b8', fontSize: '12px', margin: 0 }
