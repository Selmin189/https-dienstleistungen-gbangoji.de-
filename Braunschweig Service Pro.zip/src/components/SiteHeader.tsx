import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import logoAsset from "@/assets/logo.png.asset.json";

const nav = [
  { href: "/#start", label: "Startseite" },
  { href: "/#ueber-uns", label: "Über uns" },
  { href: "/#leistungen", label: "Leistungen" },
  { href: "/#referenzen", label: "Referenzen" },
  { href: "/#kontakt", label: "Kontakt" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all bg-background/95 backdrop-blur border-b ${
        scrolled ? "shadow-sm" : ""
      }`}
    >
      <div className="container-page flex h-20 items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group" aria-label="Dienstleistungen Galjip Bangoji – Startseite">
          <img
            src={logoAsset.url}
            alt="Dienstleistungen Galjip Bangoji Logo"
            className="h-14 md:h-16 w-auto object-contain"
            width={320}
            height={128}
          />
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {nav.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="text-sm font-medium text-foreground transition hover:text-gold"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="tel:+4917670672677"
            className="hidden md:inline-flex items-center gap-2 btn-gold rounded-md px-4 py-2.5 text-sm"
          >
            <Phone className="h-4 w-4" />
            0176 70672677
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            className="lg:hidden grid h-10 w-10 place-items-center rounded-md border border-border text-foreground"
            aria-label="Menü"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-background border-t">
          <div className="container-page flex flex-col py-4 gap-1">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="px-2 py-3 rounded-md text-foreground hover:bg-muted"
              >
                {n.label}
              </a>
            ))}
            <a href="tel:+4917670672677" className="mt-2 btn-gold rounded-md px-4 py-3 text-center text-sm">
              0176 70672677 anrufen
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
