import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Mail } from "lucide-react";
import logoAsset from "@/assets/logo.png.asset.json";

export function SiteFooter() {
  return (
    <footer className="bg-navy text-navy-foreground">
      <div className="container-page py-16 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <img
            src={logoAsset.url}
            alt="Dienstleistungen Galjip Bangoji Logo"
            className="h-24 w-auto object-contain rounded-full bg-white/95 p-1"
            width={320}
            height={128}
          />
          <p className="mt-5 text-sm text-white/70 max-w-md">
            Ihr zuverlässiger Partner für Hausmeisterservice, Gebäudereinigung, Gartenpflege,
            Entrümpelung und Renovierung in Braunschweig und Umgebung.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white gold-underline">Kontakt</h4>
          <ul className="mt-6 space-y-3 text-sm text-white/80">
            <li className="flex gap-3"><MapPin className="h-4 w-4 mt-0.5 text-gold shrink-0" />
              <span>Alte Salzdahlumer Straße 208<br />38124 Braunschweig</span>
            </li>
            <li className="flex gap-3"><Phone className="h-4 w-4 mt-0.5 text-gold shrink-0" />
              <a href="tel:+4917670672677" className="hover:text-gold">0176 70672677</a>
            </li>
            <li className="flex gap-3"><Mail className="h-4 w-4 mt-0.5 text-gold shrink-0" />
              <a href="mailto:info@dienstleistungen-gbangoji.de" className="hover:text-gold break-all">info@dienstleistungen-gbangoji.de</a>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white gold-underline">Rechtliches</h4>
          <ul className="mt-6 space-y-3 text-sm text-white/80">
            <li><Link to="/impressum" className="hover:text-gold">Impressum</Link></li>
            <li><Link to="/datenschutz" className="hover:text-gold">Datenschutz</Link></li>
            <li><a href="/#kontakt" className="hover:text-gold">Angebot anfragen</a></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-page py-6 text-xs text-white/60 flex flex-col md:flex-row gap-2 justify-between">
          <span>© {new Date().getFullYear()} Dienstleistungen Galjip Bangoji. Alle Rechte vorbehalten.</span>
          <span>Braunschweig · Wolfenbüttel · Salzgitter · Wolfsburg · Peine · Niedersachsen</span>
        </div>
      </div>
    </footer>
  );
}
