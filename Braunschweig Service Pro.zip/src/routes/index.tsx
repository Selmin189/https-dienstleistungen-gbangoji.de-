import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Leaf,
  SprayCan,
  Wrench,
  Truck,
  ShieldCheck,
  Sparkles,
  Award,
  Handshake,
  ChevronDown,
  Check,
  Clock,
} from "lucide-react";

import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { ContactForm } from "@/components/ContactForm";
import { Toaster } from "@/components/ui/sonner";

import heroImg from "@/assets/hero.png.asset.json";
import gartenImg from "@/assets/gartenpflege.jpg.asset.json";
import reinigungImg from "@/assets/reinigung.jpg.asset.json";
import hausmeisterImg from "@/assets/hausmeister.jpg.asset.json";
import entruempelungImg from "@/assets/entruempelung.jpg.asset.json";


const HOME_TITLE = "Dienstleistungen Braunschweig – Hausmeister, Reinigung, Garten | Galjip Bangoji";
const HOME_DESC = "Professionelle Dienstleistungen in Braunschweig & Niedersachsen: Hausmeisterservice, Gebäudereinigung, Gartenpflege, Entrümpelung und Renovierung. Zuverlässig, flexibel und aus einer Hand. Jetzt Angebot anfragen!";

const faq = [
  {
    q: "Welche Dienstleistungen bieten Sie an?",
    a: "Wir bieten Gartenpflege, Reinigungsarbeiten, Hausmeisterservice, Entrümpelung sowie Montage- und Renovierungsarbeiten an – alles aus einer Hand, für Privatkunden, Unternehmen und Immobilienbesitzer.",
  },
  {
    q: "Arbeiten Sie nur in Braunschweig?",
    a: "Unser Hauptgebiet ist Braunschweig. Darüber hinaus sind wir in Braunschweig und der näheren Umgebung für Sie im Einsatz.",
  },
  {
    q: "Kann ich ein kostenloses Angebot erhalten?",
    a: "Ja. Sie erhalten von uns ein transparentes, kostenloses und unverbindliches Angebot. Kontaktieren Sie uns telefonisch, per E-Mail oder über das Kontaktformular.",
  },
  {
    q: "Bieten Sie regelmäßige Objektbetreuung an?",
    a: "Selbstverständlich. Für Hausverwaltungen, Vermieter und Unternehmen übernehmen wir dauerhaft die komplette Objektbetreuung – von Reinigung über Winterdienst bis zu kleinen Reparaturen.",
  },
  {
    q: "Übernehmen Sie auch kurzfristige Aufträge?",
    a: "Ja, wir arbeiten flexibel und übernehmen bei freien Kapazitäten auch kurzfristige Aufträge in Braunschweig und Umgebung.",
  },
];

const services = [
  {
    id: "gartenpflege",
    icon: Leaf,
    title: "Gartenpflege & Außenpflege",
    desc: "Professionelle Gartenpflege in Braunschweig: Rasenmähen, Hecken- und Strauchschnitt, Unkrautentfernung, Laubarbeiten und komplette Grundstückspflege für Privatkunden und Immobilienbesitzer.",
    img: gartenImg.url,
    items: ["Rasenmähen", "Hecken- und Strauchschnitt", "Unkrautentfernung", "Laubarbeiten", "Grundstückspflege"],
  },
  {
    id: "reinigung",
    icon: SprayCan,
    title: "Reinigungsarbeiten",
    desc: "Gebäudereinigung, Büroreinigung und Fensterreinigung in Braunschweig – sauber, gründlich und termingerecht. Auch Bauendreinigung, Fassaden- und Photovoltaikreinigung.",
    img: reinigungImg.url,
    items: ["Gebäude- & Büroreinigung", "Treppenhausreinigung", "Fensterreinigung", "Bauendreinigung", "Fassaden- & Terrassenreinigung", "Photovoltaikreinigung"],
  },
  {
    id: "hausmeister",
    icon: Wrench,
    title: "Hausmeisterservice",
    desc: "Zuverlässiger Hausmeisterservice in Braunschweig und Objektbetreuung in Niedersachsen: Winterdienst, Mülltonnenservice, Schließdienst und kleine Reparaturen aus einer Hand.",
    img: hausmeisterImg.url,
    items: ["Objektbetreuung", "Winterdienst", "Mülltonnenservice", "Schließdienst", "Kleine Reparaturen"],
  },
  {
    id: "entruempelung",
    icon: Truck,
    title: "Entrümpelung & Rückbau",
    desc: "Entrümpelung und Haushaltsauflösung in Braunschweig – diskret, schnell und besenrein. Wir übernehmen Keller-, Dachboden- und Wohnungsräumungen sowie Tapetenentfernung.",
    img: entruempelungImg.url,
    items: ["Entrümpelungen", "Haushaltsauflösung", "Keller- & Dachbodenräumung", "Tapetenentfernung"],
  },
];

const trustCards = [
  { icon: ShieldCheck, title: "Zuverlässig", desc: "Wir arbeiten termintreu, sauber und professionell." },
  { icon: Handshake, title: "Flexibel", desc: "Individuelle Lösungen für jede Immobilie." },
  { icon: Award, title: "Professionelle Qualität", desc: "Saubere Arbeit und zuverlässige Ergebnisse." },
  { icon: Sparkles, title: "Alles aus einer Hand", desc: "Viele Dienstleistungen – ein Ansprechpartner." },
];

const steps = [
  { n: "01", title: "Kontakt aufnehmen", desc: "Sie erreichen uns per Telefon, E-Mail oder Kontaktformular." },
  { n: "02", title: "Besichtigung & Angebot", desc: "Wir prüfen den Auftrag und erstellen ein kostenloses Angebot." },
  { n: "03", title: "Professionelle Durchführung", desc: "Termingerechte, saubere und zuverlässige Ausführung." },
  { n: "04", title: "Zufriedener Kunde", desc: "Qualität, die überzeugt – dauerhaft und persönlich betreut." },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faq.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};

const serviceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  serviceType: "Hausmeisterservice, Gebäudereinigung, Gartenpflege, Entrümpelung, Renovierung",
  provider: { "@type": "LocalBusiness", name: "Dienstleistungen Galjip Bangoji" },
  areaServed: [
    { "@type": "City", name: "Braunschweig" },
    { "@type": "City", name: "Wolfenbüttel" },
    { "@type": "City", name: "Salzgitter" },
    { "@type": "City", name: "Wolfsburg" },
    { "@type": "State", name: "Niedersachsen" },
  ],
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Dienstleistungen",
    itemListElement: services.map((s) => ({
      "@type": "Offer",
      itemOffered: { "@type": "Service", name: s.title, description: s.desc },
    })),
  },
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: HOME_TITLE },
      { name: "description", content: HOME_DESC },
      { property: "og:title", content: HOME_TITLE },
      { property: "og:description", content: HOME_DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { property: "og:image", content: "https://www.dienstleistungen-gbangoji.de/__l5e/assets-v1/40407d90-beac-4dec-8887-bf388b93280c/hero.png" },
      { property: "og:locale", content: "de_DE" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: HOME_TITLE },
      { name: "twitter:description", content: HOME_DESC },
      { name: "twitter:image", content: "https://www.dienstleistungen-gbangoji.de/__l5e/assets-v1/40407d90-beac-4dec-8887-bf388b93280c/hero.png" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      { type: "application/ld+json", children: JSON.stringify(faqSchema) },
      { type: "application/ld+json", children: JSON.stringify(serviceSchema) },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main id="start">
        <Hero />
        <Highlights />
        <About />
        <Services />
        <TrustSection />
        <Process />
        <FAQ />
        <ContactSection />
        <CtaBanner />
      </main>
      <SiteFooter />
      <WhatsAppButton />
      <Toaster position="top-center" richColors />
    </div>
  );
}

function Hero() {
  return (
    <section className="relative isolate min-h-[92vh] flex items-center overflow-hidden">
      <img
        src={heroImg.url}
        alt="Professioneller Fensterreiniger in Braunschweig bei der Arbeit"
        width={1920}
        height={1200}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
      <div className="container-page relative z-10 pt-28 pb-20 text-white">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-4 py-1.5 text-xs font-medium backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--gold)" }} />
            Ihr Facility-Partner in Braunschweig & Niedersachsen
          </div>
          <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05] text-white">
            Zuverlässige Dienstleistungen rund um{" "}
            <span style={{ color: "var(--gold)" }}>Haus, Gebäude und Außenanlagen</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-white/85">
            Professionelle Gartenpflege, Reinigung, Hausmeisterservice, Entrümpelung und Renovierung –
            zuverlässig, flexibel und aus einer Hand.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#kontakt" className="btn-gold rounded-md px-6 py-3.5 text-sm inline-flex items-center gap-2">
              Kontaktieren Sie uns <ArrowRight className="h-4 w-4" />
            </a>
            <a href="#kontakt" className="rounded-md border border-white/40 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/15">
              Kostenloses Angebot anfragen
            </a>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-white/80">
            {["Alles aus einer Hand", "termintreu & sauber", "Persönlicher Service"].map((x) => (
              <div key={x} className="flex items-center gap-2">
                <Check className="h-4 w-4" style={{ color: "var(--gold)" }} />
                {x}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Highlights() {
  const items = [
    { icon: Phone, title: "0176 70672677", sub: "Direkt anrufen" },
    { icon: Clock, title: "Flexibel & schnell", sub: "Auch kurzfristig verfügbar" },
    { icon: MapPin, title: "Braunschweig & Umgebung", sub: "" },
  ];
  return (
    <section className="relative -mt-14 z-20">
      <div className="container-page">
        <div className="grid gap-4 md:grid-cols-3 bg-white rounded-2xl p-6 md:p-8 shadow-[var(--shadow-elegant)] border border-border">
          {items.map((it) => (
            <div key={it.title} className="flex items-center gap-4">
              <div className="grid h-12 w-12 place-items-center rounded-md" style={{ background: "var(--gradient-navy)" }}>
                <it.icon className="h-5 w-5" style={{ color: "var(--gold)" }} />
              </div>
              <div>
                <div className="text-base font-semibold text-foreground">{it.title}</div>
                <div className="text-xs text-muted-foreground">{it.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="ueber-uns" className="section-y">
      <div className="container-page max-w-3xl">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>Über uns</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold text-foreground gold-underline">
            Ihr zuverlässiger Partner rund um Immobilien in Braunschweig
          </h2>
          <p className="mt-6 text-base text-muted-foreground leading-relaxed">
            Dienstleistungen Galjip Bangoji steht für zuverlässige und professionelle Dienstleistungen
            rund um Immobilien, Gebäude und Außenanlagen. Wir unterstützen Privatkunden, Unternehmen
            und Immobilienbesitzer mit flexiblen Lösungen und sauberer Ausführung.
          </p>
          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {["Zuverlässigkeit", "Qualität", "Flexibilität", "Persönlicher Service", "Alles aus einer Hand", "Faire Preise"].map((v) => (
              <li key={v} className="flex items-center gap-3 text-sm text-foreground">
                <span className="grid h-6 w-6 place-items-center rounded-full" style={{ background: "var(--gradient-gold)" }}>
                  <Check className="h-3.5 w-3.5" style={{ color: "var(--gold-foreground)" }} />
                </span>
                {v}
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#leistungen" className="btn-navy rounded-md px-6 py-3 text-sm inline-flex items-center gap-2">
              Unsere Leistungen <ArrowRight className="h-4 w-4" />
            </a>
            <a href="tel:+4917670672677" className="rounded-md border border-input px-6 py-3 text-sm font-semibold text-foreground hover:bg-muted">
              0176 70672677
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="leistungen" className="section-y bg-muted/60">
      <div className="container-page">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>Leistungen</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold text-foreground gold-underline-center">
            Unsere Dienstleistungen für Sie
          </h2>
          <p className="mt-6 text-muted-foreground">
            Vom gepflegten Garten bis zur schlüsselfertigen Renovierung – wir übernehmen die komplette
            Betreuung Ihrer Immobilie in Braunschweig und Umgebung.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <article key={s.id} id={s.id} className="group flex flex-col rounded-2xl overflow-hidden bg-white border border-border shadow-sm hover:shadow-[var(--shadow-elegant)] transition-all">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={s.img}
                  alt={`${s.title} in Braunschweig – Dienstleistungen Galjip Bangoji`}
                  width={1200}
                  height={900}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 grid h-11 w-11 place-items-center rounded-md" style={{ background: "var(--gradient-gold)" }}>
                  <s.icon className="h-5 w-5" style={{ color: "var(--gold-foreground)" }} />
                </div>
              </div>
              <div className="p-6 flex flex-col grow">
                <h3 className="text-xl font-semibold text-foreground">{s.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
                <ul className="mt-4 space-y-1.5 text-sm text-foreground/80">
                  {s.items.map((it) => (
                    <li key={it} className="flex items-start gap-2">
                      <Check className="h-4 w-4 mt-0.5 shrink-0" style={{ color: "var(--gold)" }} />
                      {it}
                    </li>
                  ))}
                </ul>
                <a href="#kontakt" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-navy hover:gap-3 transition-all" style={{ color: "var(--navy)" }}>
                  Mehr erfahren <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function TrustSection() {
  return (
    <section className="section-y relative overflow-hidden" style={{ background: "var(--gradient-navy)" }}>
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, var(--gold) 0, transparent 40%), radial-gradient(circle at 80% 80%, var(--gold) 0, transparent 40%)" }} />
      <div className="container-page relative">
        <div className="max-w-2xl mx-auto text-center text-white">
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>Warum wir</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold gold-underline-center">
            Warum Kunden uns vertrauen
          </h2>
          <p className="mt-6 text-white/75">
            Als lokaler Dienstleister aus Braunschweig verbinden wir handwerkliche Qualität mit
            persönlichem Service.
          </p>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {trustCards.map((c) => (
            <div key={c.title} className="rounded-2xl bg-white/5 border border-white/10 p-8 backdrop-blur hover:bg-white/10 transition">
              <div className="grid h-12 w-12 place-items-center rounded-md" style={{ background: "var(--gradient-gold)" }}>
                <c.icon className="h-5 w-5" style={{ color: "var(--gold-foreground)" }} />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-white">{c.title}</h3>
              <p className="mt-2 text-sm text-white/75">{c.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section className="section-y">
      <div className="container-page">
        <div className="max-w-2xl mx-auto text-center">
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>Ablauf</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold text-foreground gold-underline-center">So einfach arbeiten wir</h2>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <div key={s.n} className="relative rounded-2xl border border-border bg-white p-8 hover:shadow-[var(--shadow-elegant)] transition">
              <div className="text-5xl font-bold" style={{ fontFamily: "var(--font-display)", color: "var(--gold)" }}>{s.n}</div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              {i < steps.length - 1 && (
                <ArrowRight className="hidden lg:block absolute -right-3 top-10 h-6 w-6 text-border" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="section-y">
      <div className="container-page grid gap-12 lg:grid-cols-[1fr_1.4fr] items-start">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>FAQ</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold text-foreground gold-underline">Häufig gestellte Fragen</h2>
          <p className="mt-6 text-muted-foreground">
            Sie haben weitere Fragen? Rufen Sie uns an oder schreiben Sie uns – wir beraten Sie
            gerne persönlich.
          </p>
          <a href="tel:+4917670672677" className="mt-6 inline-flex btn-gold rounded-md px-6 py-3 text-sm items-center gap-2">
            <Phone className="h-4 w-4" /> 0176 70672677
          </a>
        </div>
        <div className="divide-y divide-border rounded-2xl border border-border bg-white">
          {faq.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={f.q}>
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-6 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="text-base font-semibold text-foreground">{f.q}</span>
                  <ChevronDown className={`h-5 w-5 shrink-0 transition ${isOpen ? "rotate-180" : ""}`} style={{ color: "var(--gold)" }} />
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 -mt-2 text-sm text-muted-foreground leading-relaxed">
                    {f.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section id="kontakt" className="section-y bg-muted/60">
      <div className="container-page grid gap-12 lg:grid-cols-2">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.2em]" style={{ color: "var(--gold)" }}>Kontakt</div>
          <h2 className="mt-3 text-3xl md:text-4xl font-bold text-foreground gold-underline">Kontaktieren Sie uns!</h2>
          <p className="mt-6 text-muted-foreground max-w-lg">
            Sie möchten ein unverbindliches Angebot oder haben Fragen zu unseren Dienstleistungen in
            Braunschweig? Wir melden uns schnellstmöglich bei Ihnen zurück.
          </p>
          <div className="mt-8 space-y-4">
            <ContactRow icon={Phone} label="Telefon" value="0176 70672677" href="tel:+4917670672677" />
            <ContactRow icon={Mail} label="E-Mail" value="info@dienstleistungen-gbangoji.de" href="mailto:info@dienstleistungen-gbangoji.de" />
            <ContactRow icon={MapPin} label="Adresse" value="Alte Salzdahlumer Straße 208, 38124 Braunschweig" />
          </div>
          <a
            href="https://wa.me/4917670672677"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-2 rounded-md px-5 py-3 text-sm font-semibold text-white"
            style={{ background: "#25D366" }}
          >
            <svg viewBox="0 0 32 32" className="h-4 w-4" fill="currentColor" aria-hidden="true">
              <path d="M19.11 17.44c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.08-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.08-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35z"/>
            </svg>
            Nachricht via WhatsApp
          </a>
        </div>
        <div className="rounded-2xl bg-white p-6 md:p-8 border border-border shadow-[var(--shadow-elegant)]">
          <h3 className="text-xl font-semibold text-foreground">Kostenloses Angebot anfragen</h3>
          <p className="mt-1 text-sm text-muted-foreground">Wir antworten in der Regel innerhalb von 24 Stunden.</p>
          <div className="mt-6">
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactRow({ icon: Icon, label, value, href }: { icon: typeof Phone; label: string; value: string; href?: string }) {
  const content = (
    <>
      <div className="grid h-11 w-11 place-items-center rounded-md" style={{ background: "var(--gradient-navy)" }}>
        <Icon className="h-5 w-5" style={{ color: "var(--gold)" }} />
      </div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-base font-medium text-foreground">{value}</div>
      </div>
    </>
  );
  return href ? (
    <a href={href} className="flex items-center gap-4 hover:opacity-80 transition">{content}</a>
  ) : (
    <div className="flex items-center gap-4">{content}</div>
  );
}

function CtaBanner() {
  return (
    <section className="section-y">
      <div className="container-page">
        <div className="relative overflow-hidden rounded-3xl p-10 md:p-16 text-white" style={{ background: "var(--gradient-navy)" }}>
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full opacity-30" style={{ background: "var(--gradient-gold)", filter: "blur(60px)" }} />
          <div className="relative max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-bold" style={{ fontFamily: "var(--font-display)" }}>
              Bereit für einen zuverlässigen <span style={{ color: "var(--gold)" }}>Dienstleister</span>?
            </h2>
            <p className="mt-4 text-white/80">
              Kontaktieren Sie uns noch heute und erhalten Sie Ihr kostenloses Angebot für Braunschweig.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="tel:+4917670672677" className="btn-gold rounded-md px-6 py-3.5 text-sm inline-flex items-center gap-2">
                <Phone className="h-4 w-4" /> Jetzt anrufen
              </a>
              <a href="#kontakt" className="rounded-md border border-white/40 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur hover:bg-white/15">
                Kontakt aufnehmen
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
